module.exports = {
  posgresqlURI: process.env.POSGRESQL_URI,
};